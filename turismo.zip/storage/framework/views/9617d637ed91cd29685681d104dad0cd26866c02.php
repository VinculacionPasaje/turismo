<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">


   <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Titulo'); ?>

                            <?php echo Form::text('titulo',null,['placeholder'=>'Nombre','class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Fecha Noticia'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker" name = "fecha_post" value="<?php echo e(old('fecha_post')); ?>">
                        </div>
                    </div>
                </div>

</div>

<div class="form-group">
    <?php echo Form::label('Descripción'); ?>

    <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control']); ?>

</div>

<div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Foto','Foto:'); ?>

                            <?php echo Form::file('path',['class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <label>Categoria</label>
                            <select class="form-control select2" name="alimentacion_id" id="alimentacion_id" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione la categoria</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if(old('alimentacion_id') == $categoria->id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->nombre_lugar); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre_lugar); ?></option>
                                    <?php endif; ?>             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                            </select>
                        </div>
                </div>

</div>

<div class="row" ><!--Inicio de row -->
                 
                <div align="center" class="col-md-12 col-xs-12">
                        
                     <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

                </div>

</div>









 





