<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">


   <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Evento'); ?>

                            <?php echo Form::text('titulo',null,['placeholder'=>'Escriba el evento','class'=>'form-control']); ?>

                        </div>
                </div>

                 <div class="col-md-4 col-xs-12">
                           <div class="bootstrap-timepicker">
                                <div class="form-group">
                                <?php echo Form::label('Hora de Inicio'); ?>


                                <div class="input-group">
                                    <input type="text" class="form-control timepicker" name ="hora_inicio">

                                    <div class="input-group-addon">
                                    <i class="fa fa-clock-o"></i>
                                    </div>
                                </div>
                                <!-- /.input group -->
                                </div>
                            <!-- /.form group -->
                        </div>
                </div>
                

</div>


<div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                                <?php echo Form::label('Descripción corta del Evento'); ?>

                                <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control']); ?>

                            </div>
                        </div>
                <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                                <?php echo Form::label('Dirección del Evento'); ?>

                                <?php echo Form::text('direccion',null,['placeholder'=>'Dirección','class'=>'form-control']); ?>

                            </div>
                        </div>
                </div>

</div>





<div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Foto','Foto:'); ?>

                            <?php echo Form::file('path',['class'=>'form-control']); ?>

                        </div>
                </div>

                    <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Precio Evento'); ?>

                            <?php echo Form::number('precio',null,['placeholder'=>'Precio Evento','class'=>'form-control' ,'step' => 'any']); ?>

                        </div>
                     </div>

             
               

</div>


<div class="row" ><!--Inicio de row -->
                

                <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Desde'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker" name = "fecha_desde" value="<?php echo e(old('fecha_desde')); ?>">
                        </div>
                    </div>
                </div>

                   <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Hasta'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker2" name = "fecha_hasta" value="<?php echo e(old('fecha_hasta')); ?>">
                        </div>
                    </div>
                </div>
               

</div>


<div class="row" ><!--Inicio de row -->
                

                 <div class="col-md-4 col-xs-12">
                        <div class="form-group">
                            <label>Seleccione la categoria</label>
                            <select class="form-control select2" name="categoria_id" id="categorias" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione alguna</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if(old('categoria_id') == $categoria->id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->categoria); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria); ?></option>
                                    <?php endif; ?>             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                            </select>
                        </div>
                </div>

                  <div class="col-md-4 col-xs-12">
                        
                    <div class="form-group">
                            <label>Seleccione la Ubicación</label>
                            <select class="form-control select2" name="parroquias_id" id="parroquias" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione la Parroquia</option>
                                <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parroquia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if(old('parroquias_id') == $parroquia->id): ?>
                                        <option value="<?php echo e($parroquia->id); ?>" selected><?php echo e($parroquia->parroquia); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($parroquia->id); ?>"><?php echo e($parroquia->parroquia); ?></option>
                                    <?php endif; ?>             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                            </select>
                        </div>
                </div>

                <div class="col-md-4 col-xs-12">
                        
                     <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

                </div>

</div>

<div class="form-group">
    <?php echo Form::label('Script de Google Maps (Ubicación del Evento))'); ?>

    <?php echo Form::text('script',null,['placeholder'=>'ingrese el script de google map','class'=>'form-control']); ?>

</div>








  <div class="form-group">
                <?php echo Form::label('Contenido'); ?>

                
                                                
                <?php echo Form::textarea('contenido',null,['class'=>'form-control', 'rows' => 50]); ?>

                                
</div>