<?php $__env->startSection('title'); ?>
<title>Actividades Deportivas</title>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu'); ?>

                    <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categorias->count()): ?>
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li><a href="#"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a tabindex="-1" href="#">Atractivos Turísticos</a>
                                        <ul class="dropdown-menu">
                                                <li><a tabindex="-1" href="#">Parroquias</a></li>
                                                <li><a tabindex="-1" href="#">Iglesias</a></li>
                                                <li><a tabindex="-1" href="#">Parques y Monumentos</a></li>
                                                <li><a tabindex="-1" href="#">Rutas Turísticas</a></li>
                                                <li><a tabindex="-1" href="#">Sitios Tradicionales</a></li>
                                                 <li><a tabindex="-1" href="#">Manifestaciones Culturales</a></li>
                                                  <li><a tabindex="-1" href="#">Sitios Arqueológicos</a></li>
                                                   <li><a tabindex="-1" href="#">Sitios Naturales</a></li>
                                        </ul>
                                 </li>   
                                 <li><a href="#">Turismo Comunitario</a></li>           
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a tabindex="-1" href="#">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                                <li><a tabindex="-1" href="#">Hosterías</a></li>
                                                <li><a tabindex="-1" href="#">Hoteles</a></li>
                                                 <li><a tabindex="-1" href="#">Hostales</a></li>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a tabindex="-1" href="#">Alimentación</a>
                                        <ul class="dropdown-menu">
                                                <li><a tabindex="-1" href="#">Restaurantes</a></li>
                                                <li><a tabindex="-1" href="#">Cafeterias</a></li>
                                                <li><a tabindex="-1" href="#">Fuentes de Soda</a></li>
                                                
                                        </ul>
                                 </li> 

                                  <li class="dropdown-submenu">
                                        <a tabindex="-1" href="#">Diversión</a>
                                        <ul class="dropdown-menu">
                                                <li><a tabindex="-1" href="#">Discotecas</a></li>
                                                <li><a tabindex="-1" href="#">Centro de eventos</a></li>
                                                <li><a tabindex="-1" href="#">Bares</a></li>
                                                 <li><a tabindex="-1" href="#">Karaokes</a></li>
                                                
                                        </ul>
                                 </li>   
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 
                                <li><a href="#">Dirección de Turismo</a></li>
                                <li><a href="#">Agenda de Eventos</a></li>
                                <li><a href="#">Proyectos</a></li>  
                                <li><a href="#">Catastros Turísticos</a></li>               
                            </ul>
                          </li> 




<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu2'); ?>

                <li class="active"><a href="#"><i class="fa fa-home fa-fw"></i>Home</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="glyphicon glyphicon-chevron-right"></i>Widgets</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-file-o fa-fw"></i>Pages</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-bar-chart-o fa-fw"></i>Charts</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-table fa-fw"></i>Table</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-tasks fa-fw"></i>Forms</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-calendar fa-fw"></i>Calender</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-book fa-fw"></i>Library</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-pencil fa-fw"></i>Applications</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-cogs fa-fw"></i>Settings</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

<p>Bloque central</p>
<?php $__env->stopSection(); ?>










<?php $__env->startSection('footer'); ?>

<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>