<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>
            Inicio
            <small>Listar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Inicio</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensaje-registro')): ?>
        <?php echo $__env->make('mensajes.msj_correcto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Contenido Registrado</h3>

                   
                </div>
                <!-- /.box-header -->
                <?php if(count($traer) >0): ?>
                    <div class="ajax-tabla">
                        <div class="box-body table-responsive no-padding" >
                            <table class="table table-hover" >
                                <tr>
                                    <th>Contenido</th>
                                    <th>Fecha</th>
                                    <th>Visitas</th>
                                    <th>Acción</th>
                                </tr>
                                <?php $__currentLoopData = $traer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-id="<?php echo e($item->id); ?>">
                                        <td class="sorting_1"><?php echo $item->contenido; ?></td>
                                        <td><?php echo e($item->fecha); ?></td>
                                        <td><?php echo e($item->contador_visitas); ?></td>
                                        <td>
                                            <?php echo link_to_route('traer.edit', $title = 'Editar', $parameters = $item->id, $attributes = ['class'=>'btn  btn-primary btn-sm']); ?>

                                            

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <?php echo e($traer->links()); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <br/><div class='rechazado'><label style='color:#FA206A'>...No se ha encontrado ningun contenido...</label>  </div>
                <?php endif; ?>
            </div>
            <!-- /.box -->
        </div>
    </div>

    
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $(".aprobado").fadeOut(300);
            },3000);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>