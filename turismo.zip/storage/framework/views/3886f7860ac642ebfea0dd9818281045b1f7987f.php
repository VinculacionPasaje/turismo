<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>
            Inicio
            <small>Listar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Inicio</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensaje-registro')): ?>
        <?php echo $__env->make('mensajes.msj_correcto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <div class= "col-xs-6 col-md-6" aling="center">
                        <h3 class="box-title">Fotos Guia Turísticas Registrados</h3>

                    </div>
                    
                     
                </div>
                <!-- /.box-header -->
                <?php if(count($fotos) >0): ?>

                

                  <div class="ajax-tabla">
                        <div class="box-body table-responsive no-padding" >
                            <table id="example2" class="table table-hover" >
                            <thead>
                                <tr>
                                    <th>Foto</th>
                                    <th>Orden</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($noticia->estado !=0): ?>
                                    <tr data-id="<?php echo e($noticia->id); ?>">
                                        <td>
                                            <img src="<?php echo e(url('fotos/'.$noticia->path)); ?>" alt="" style="width:70px;"/>
                                        </td>
                                    
                                        <td><?php echo e($noticia->orden); ?></td>
                                       
                                        <td>
                                            <?php echo link_to_route('guiaFotos.edit', $title = 'Editar', $parameters = $noticia->id, $attributes = ['class'=>'btn  btn-primary btn-sm']); ?>

                                            <button type="button" class="btn btn-danger btn-sm btn-delete"  ><i class="zmdi zmdi-floppy"></i> &nbsp;&nbsp;Eliminar</button>
                                        </td>

                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <?php echo e($fotos->links()); ?>

                        </div>
                    </div>
                         

               
                <?php else: ?>
                    <br/><div class='rechazado'><label style='color:#FA206A'>...No se ha encontrado ningun contenido...</label>  </div>
                <?php endif; ?>
          
            </div>
            <!-- /.box -->
        </div>
    </div>

    <?php echo Form::open(['route' => ['guiaFotos.destroy', ':USER_ID'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('administration/dist/js/hospedaje/java-hospedaje.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $(".aprobado").fadeOut(300);
            },3000);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>