<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>
            Categorias
            <small>Editar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Categorias</li>
            <li class="active">Editar</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if(!$errors->isEmpty()): ?>
        <div class="alert alert-danger">
            <p><strong>Error!! </strong>Corrija los siguientes errores</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
    <?php endif; ?>


    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">Edición de Categoría</h3>
        </div><!-- /.box-header -->

        <div id="notificacion_resul_fanu"></div>
        <div class="box-body">
            <?php echo e(Form::model($categoria, ['route' => ['categoriasGastronomia.update',$categoria->id],'method'=>'PUT' ])); ?>

                <input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">
                <div class="form-group">
                    <?php echo Form::label('Nombre'); ?>

                    <?php echo Form::text('categoria',null,['placeholder'=>'Nombre','class'=>'form-control','onkeypress'=>'return soloLetras(event)']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('Descripción'); ?>

                    <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control','onkeypress'=>'return soloLetras(event)']); ?>

                </div>
                <?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('administration/dist/js/categorias/java-categoria.js')); ?>"></script>
    <script src="<?php echo e(url('administration/dist/js/validaNumerosLetras.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>