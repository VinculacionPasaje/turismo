<?php $__env->startSection('title'); ?>
<title><?php echo e($categoriasAct->categoria); ?></title>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu'); ?>

                    <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categorias->count()): ?>
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li><a href="<?php echo e(url('categoria/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                         <a href="<?php echo e(url ('atractivosTuristicos')); ?>">Atractivos Turísticos</a>
                                        <ul class="dropdown-menu">
                                               <?php if($categoriasTu->count()): ?>
                                                    <?php $__currentLoopData = $categoriasTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaTuristico/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </ul>
                                 </li>   
                               <li><a href="<?php echo e(url ('turismoComunitario')); ?>">Turismo Comunitario</a></li>              
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('hospedaje')); ?>">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasHospedaje->count()): ?>
                                                    <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaHospedaje/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('alimentacion')); ?>">Alimentacion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasAlimentacion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasAlimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaAlimentacion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>

                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('diversion')); ?>">Diversion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasDiversion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasDiversion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaDiversion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 
                                <li><a href="#">Proceso de Licencia Turistica LOAF</a></li>
                                <li><a href="<?php echo e(url ('eventos')); ?>">Agenda de Eventos</a></li>
                                <li><a href="#">Proyectos</a></li>  
                                <li><a href="#">Catastros Turísticos</a></li>               
                            </ul>
                          </li> 




<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu2'); ?>

         <?php if($actividades->count()): ?>
                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><a href="<?php echo e(url('hospedaje/'.$act->id)); ?>"><i class="glyphicon glyphicon-chevron-right" style="padding-right: 15px;"></i><?php echo e($act->titulo); ?></a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

                
                
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('encabezado'); ?>

<?php echo e($categoriasAct->categoria); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>



<div class= "col-xs-12 col-md-12" aling="center">
 <p class="contact2"> <?php echo e($categoriasAct->categoria); ?> </p>
        <p style="font-color='black';"> <span class="fa fa-eye"></span> Visto: <?php echo e($variable->contador_visitas); ?> </p>
</div>

<?php echo $categoriasAct->descripcion; ?>

<div class= "col-xs-12 col-md-12">

<div class="post-comments">

    <form>
      <div class="form-group">
        <label for="comment">Tu comentario</label>
        <textarea name="comment" class="form-control" rows="3"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </form>

    <div class="comments-nav">
      <ul class="nav nav-pills">
        <li role="presentation" class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style="margin-top: 10px; margin-bottom: 10px;">
                  Hay 2 comments <span class="caret"></span>
                </a>
          <ul class="dropdown-menu">
            <li><a href="#">Más votado</a></li>
            <li><a href="#">Recientes</a></li>
          </ul>
        </li>
      </ul>
    </div>

    <div class="row">

      <div class="media">
        <!-- first comment -->

        <div class="media-heading">
          <button class="btn btn-default btn-xs" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseExample"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button> <span class="label label-info">12314</span> 
          Enviado hace 12 horas
        </div>

        <div class="panel-collapse collapse in" id="collapseOne">

          <div class="media-left">
            <div class="vote-wrap">
              <div class="save-post">
                <a href="#"><span class="glyphicon glyphicon-star" aria-label="Save"></span></a>
              </div>
              <div class="vote up">
                <i class="glyphicon glyphicon-menu-up"></i>
              </div>
              <div class="vote inactive">
                <i class="glyphicon glyphicon-menu-down"></i>
              </div>
            </div>
            <!-- vote-wrap -->
          </div>
          <!-- media-left -->


          <div class="media-body">
            <p>este es un comentario</p>
            <div class="comment-meta">
              <span><a href="#">Borrar</a></span>
              <span><a href="#">Reportar</a></span>
              <span><a href="#">Ocultar</a></span>
              <span>
                        <a class="" role="button" data-toggle="collapse" href="#replyCommentT" aria-expanded="false" aria-controls="collapseExample">Responder</a>
                      </span>
              <div class="collapse" id="replyCommentT">
                <form>
                  <div class="form-group">
                    <label for="comment">Tu comentario</label>
                    <textarea name="comment" class="form-control" rows="3"></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary">Enviar</button>
                </form>
              </div>
            </div>
            <!-- comment-meta -->

            <div class="media">
              <!-- answer to the first comment -->

              <div class="media-heading">
                <button class="btn btn-default btn-collapse btn-xs" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseExample"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button> <span class="label label-info">12314</span> Enviado hace 5 horas
              </div>

              <div class="panel-collapse collapse in" id="collapseTwo">

                <div class="media-left">
                  <div class="vote-wrap">
                    <div class="save-post">
                      <a href="#"><span class="glyphicon glyphicon-star" aria-label="Save"></span></a>
                    </div>
                    <div class="vote up">
                      <i class="glyphicon glyphicon-menu-up"></i>
                    </div>
                    <div class="vote inactive">
                      <i class="glyphicon glyphicon-menu-down"></i>
                    </div>
                  </div>
                  <!-- vote-wrap -->
                </div>
                <!-- media-left -->


                <div class="media-body">
                  <p>Te responde a tu comentario.</p>
                  <div class="comment-meta">
                    <span><a href="#">Borrar</a></span>
                    <span><a href="#">Reportar</a></span>
                    <span><a href="#">Ocultar</a></span>
                            <span>
                              <a class="" role="button" data-toggle="collapse" href="#replyCommentThree" aria-expanded="false" aria-controls="collapseExample">Responder</a>
                            </span>
                    <div class="collapse" id="replyCommentThree">
                      <form>
                        <div class="form-group">
                          <label for="comment">Tu comentario</label>
                          <textarea name="comment" class="form-control" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Enviar</button>
                      </form>
                    </div>
                  </div>
                  <!-- comment-meta -->
                </div>
              </div>
              <!-- comments -->

            </div>
            <!-- answer to the first comment -->

          </div>
        </div>
        <!-- comments -->

      </div>

     
    </div> <!-- row -->

  </div>   <!-- post-comments -->


</div>
<?php $__env->stopSection(); ?>










<?php $__env->startSection('footer'); ?>

<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==5): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoPinterest" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>