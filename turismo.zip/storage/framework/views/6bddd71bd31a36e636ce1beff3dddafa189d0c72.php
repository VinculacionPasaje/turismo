<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">


   <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Parroquia'); ?>

                            <?php echo Form::text('parroquia',null,['placeholder'=>'Parroquia','class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Fecha Post'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker" name = "fecha_post" value="<?php echo e(old('fecha_post')); ?>">
                        </div>
                    </div>
                </div>

</div>


<div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Foto','Foto:'); ?>

                            <?php echo Form::file('path',['class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <label>Zonas</label>
                            <select class="form-control select2" name="id_zonas" id="zonas" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione la zona</option>
                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if(old('id_zonas') == $zona->id): ?>
                                        <option value="<?php echo e($zona->id); ?>" selected><?php echo e($zona->zona); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($zona->id); ?>"><?php echo e($zona->zona); ?></option>
                                    <?php endif; ?>             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                            </select>
                        </div>
                </div>

</div>

<div class="row" ><!--Inicio de row -->
    <div class="col-md-6 col-xs-12">


        <div class="form-group">
            <?php echo Form::label('Descripción'); ?>

            <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control']); ?>

        </div>

     </div>

      <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <label>Tipo de Parroquia</label>
                            <select class="form-control select2" name="tipo_parroquia" id="tipo_parroquia" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione el tipo de parroquia</option>
                              
                                   <?php if(old('tipo_parroquia') == "Urbano"): ?>
                                        <option value="Urbano" selected>Parroquia Urbana</option>
                                         <option value="Rural">Parroquia Rural</option>
                                    <?php else: ?>

                                         <?php if(old('tipo_parroquia') == "Rural"): ?>

                                           <option value="Rural" selected>Parroquia Rural</option>
                                            <option value="Urbano">Parroquia Urbana</option>
                                         <?php else: ?>
                                            <option value="Urbano">Parroquia Urbana</option>
                                            <option value="Rural">Parroquia Rural</option>

                                         <?php endif; ?>
                                       
                                    <?php endif; ?>             
                              
                                 
                            </select>
                        </div>
                </div>




</div>




<div class="form-group">
                <?php echo Form::label('Contenido'); ?>

                
                                                
                <?php echo Form::textarea('contenido',null,['class'=>'form-control', 'rows' => 50]); ?>

                                
</div>

<div class="form-group">
                <?php echo Form::label('¿Que Traer?'); ?>

                
                                                
                <?php echo Form::textarea('traer',null,['class'=>'form-control', 'rows' => 50]); ?>

                                
</div>

<div class="row" ><!--Inicio de row -->
                
                <div class="col-md-6 col-xs-12">
                        
                     <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

                </div>

</div>