<b>De: </b> Administrador de Turismo de Pasaje
<br>
<br>
<b> Pregunta: </b> {{ $comentario }}
<br>
<br>

<b> Respuesta: </b> {{ $respuesta_comentario }}

<br>
<br>
<b> Señor invitado responder a este correo: </b> grupoturismopasaje@gmail.com