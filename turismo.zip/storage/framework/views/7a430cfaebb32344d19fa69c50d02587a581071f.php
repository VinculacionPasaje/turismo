 <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                                    

                                    <div class="col-lg-4 col-md-6 col-sm-6 padding-botton25px">

                                            <div class="news">
                                                        <div class="img-figure">
                                                               <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($cat->id == $act->id_categorias ): ?>

                                                                    <div class="cat"><?php echo e($cat->categoria); ?></div>
                                                                    <?php endif; ?>

                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           
                                                            <img src="<?php echo e(url('fotos/'.$act->path)); ?>" class="img-responsive">
                                                        </div>	

                                                        <div class="title">
                                                            <h1><?php echo e($act->titulo); ?></h1>
                                                        </div>
                                                        <p class="description">
                                                            <?php echo e($act->descripcion); ?>

                                                        </p>

                                                        <p class="more">
                                                            <a href="<?php echo e(url ('hospedaje/'.$act->id)); ?>">Leer Más</a><i class="fa fa-angle-right" aria-hidden="true"></i>
                                                        </p>
                                                </div>


                                        
                                     </div>
              
                                      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 