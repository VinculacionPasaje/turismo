<?php $__env->startSection('title'); ?>
<title><?php echo e($actividad->nombre_lugar); ?></title>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('menu'); ?>

                    <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categorias->count()): ?>
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li><a href="<?php echo e(url('categoria/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                         <a href="<?php echo e(url ('atractivosTuristicos')); ?>">Atractivos Turísticos</a>
                                        <ul class="dropdown-menu">
                                                <?php if($categoriasTu->count()): ?>
                                                    <?php $__currentLoopData = $categoriasTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaTuristico/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </ul>
                                 </li>   
                                   
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('hospedaje')); ?>">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasHospedaje->count()): ?>
                                                    <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaHospedaje/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                   <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('alimentacion')); ?>">Alimentacion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasAlimentacion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasAlimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaAlimentacion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>

                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('diversion')); ?>">Diversion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasDiversion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasDiversion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaDiversion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#" onclick="window.open('pdf/guia_turistica.pdf')">Guía Turística</a></li> 
                                <li><a href="#">Proceso de Licencia Turistica LOAF</a></li>
                                <li><a href="<?php echo e(url ('eventos')); ?>">Agenda de Eventos</a></li>
                                <li><a href="#">Proyectos</a></li>  
                                <li><a href="#">Catastros Turísticos</a></li>               
                            </ul>
                          </li> 




<?php $__env->stopSection(); ?>

<?php $__env->startSection('encabezado'); ?>

<?php echo e($categoriasAct->categoria); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu2'); ?>

        <?php if($actividades->count()): ?>
                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><a href="<?php echo e(url('alimentacion/'.$act->id)); ?>"><i class="glyphicon glyphicon-chevron-right" style="padding-right: 15px;"></i><?php echo e($act->nombre_lugar); ?></a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

<div class= "col-xs-12 col-md-12" aling="center">
 <p class="contact2"> <?php echo e($actividad->nombre_lugar); ?> </p>
        <p style="font-color='black';"> <span class="fa fa-eye"></span> Visto: <?php echo e($variable->contador_visitas); ?> </p>
</div>

<?php echo $actividad->contenido; ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('contenido2'); ?>


<div class= "col-xs-12 col-md-12">

            <div class="row header">
                                <div class="col-lg-12 col-md-12 col-sm-12">

                                        <h2 class="column-title2"> Galeria de Imágenes </h2>

                                            


                                    
                                </div>
                </div>




                    <div class="col-lg-12 col-md-12 col-sm-12" >

                    <?php if(count($imagenes) >0): ?>

                            <?php echo $__env->make('ajax-frontend/galeria', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                    <?php else: ?>

                                        <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                                            <img src="<?php echo e(url('frontend/images/sad.png')); ?>">

                                                    <p> No se encontraron imágenes </p>

                                            </div>



                    <?php endif; ?>
                    


                    

                    </div>  
</div>  



     <div class="row header">
            <div class="col-lg-12 col-md-12 col-sm-12">

                    <h2 class="column-title2"> Deja tu Comentario </h2>


                
            </div>
  </div>

	

	<div class="row">
		<div id="comment-form" class="col-xs-12 col-md-12" style="margin-top: 20px;">
			<?php echo e(Form::open(['route' => ['comentariosAlimentacion2.store', $actividad->id], 'method' => 'POST'])); ?>

      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
          
				
				<div class="row">
					<div class="col-md-6">
						<?php echo e(Form::label('name', "Nombre:")); ?>

            <input id="nombre" type="text" class="form-control" name="nombre" required placeholder="Ingrese su nombre *">
					
					</div>

					<div class="col-md-6">
						<?php echo e(Form::label('email', 'Email:')); ?>

            
					 <input id="email" type="email" class="form-control" name="email" required placeholder="Correo Electronico *">
					</div>

					<div class="col-md-12">
						<?php echo e(Form::label('comment', "Comentario:")); ?>


            <textarea name="comentario" id="comentario" required placeholder="Comentario *" class="form-control" rows="5"></textarea>
					

						
					</div>

          <div align="center" class="col-lg-12 col-md-12 col-sm-12">

          <?php echo e(Form::submit('Comentar', ['class' => ' slider_btn4', 'style' => 'margin-top:15px;'])); ?>


          </div>
				</div>

			<?php echo e(Form::close()); ?>

		</div>
	</div>



<div class= "col-xs-12 col-md-12">

      <div class="row header">
                  <div class="col-lg-12 col-md-12 col-sm-12">

                          <h4 class="column-title2"> Comentarios </h4>

                             


                      
                  </div>
        </div>




  <div class="post-comments col-lg-12 col-md-12 col-sm-12" id="post-data" >

          
      <?php echo $__env->make('ajax-frontend/comentariosActividades', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>   <!-- post-comments -->


    <?php if(count($comentarios) >0): ?>

     <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                        <button type= "button" class="slider_btn4 loadMore"> Ver Mas </button>

                        </div>
                
                <div class="ajax-load text-center" style="display:none">
                            <p><img src="<?php echo e(url('frontend/images/loader.gif')); ?>">Cargando más post</p>
                        </div>
      <?php else: ?>

                         <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                             <img src="<?php echo e(url('frontend/images/sad.png')); ?>">

                                    <p> No se encontraron resultados </p>

                             </div>



      <?php endif; ?>

</div>




<?php $__env->stopSection(); ?>











<?php $__env->startSection('footer'); ?>

<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>
                                                
                                                <?php if($red->id==5): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoPinterest" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

 


   <script type="text/javascript">
            var page = 1;


            $(document).ready(function(){

                            $('.loadMore').click(function(){

                                page++;
                                loadMoreData(page);

                        


                                });

                        });

            function loadMoreData(page){
            $.ajax(
                    {
                        url: '?page=' + page,
                        type: "get",
                        beforeSend: function()
                        {
                            $('.ajax-load').show();
                        }
                    })
                    .done(function(data)
                    {
                        if(data.html.length == "0"){
                            $('.loadMore').text("Ya no hay más comentarios").attr("disabled", "disabled");
                            $('.ajax-load').html("Ya no hay mas resultados");
                        return;
                        }
                        $('.ajax-load').hide();
                        $("#post-data").append(data.html);
                    })
                    .fail(function(jqXHR, ajaxOptions, thrownError)
                    {
                        alert('error al cargar los datos...');
                    });
            }
        </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>