<!doctype html>
<html class="home no-js" lang="">

<head>
  <!-- meta -->
 <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
   
  <!-- /meta -->

   <title>¿Cómo Llegar?</title>

   <link rel="stylesheet" href="<?php echo e(url('frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/prettyPhoto.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/bootstrap-submenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/mensajes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/alertify.css')); ?>">


    <link rel="shortcut icon" href="<?php echo e(url('frontend/images/ico/ico.ico')); ?>">
  
  


  
</head>


<body id="home" class="homepage" style="background: rgb(255, 255, 255);">
  

   <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    
    <header id="header">
        
        <nav id="main-menu" class="navbar navbar-default navbar-static-top" role="banner">

            
            

            

            <div class="container">
                
                <div class="navbar-header">
                    

                    
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    

                    
                    <a class="navbar-brand" href="<?php echo e(url ('/')); ?>"><img src="<?php echo e(url('frontend/images/logo2.png')); ?>" alt="logo"></a>
                </div>

                


                
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="scroll active"><a href="<?php echo e(url ('/')); ?>">INICIO</a></li>
						
						
                          <li class="dropdown">
						
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">PASAJE<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                             <li><a href="<?php echo e(url ('parroquias')); ?>">Parroquias</a></li>
                                <li><a href="<?php echo e(url ('llegar')); ?>">¿Cómo Llegar?</a></li>
                                <li><a href="<?php echo e(url ('mapas')); ?>">Mapas</a></li>  
                                
                                <li><a href="<?php echo e(url ('preguntas')); ?>">Preguntas Frecuentes</a></li>   
                                <li><a href="<?php echo e(url ('material')); ?>">Material Turístico</a></li>            
                            </ul>
                             </li> 

                        <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                       <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categoriasAct->count()): ?>
                                            <?php $__currentLoopData = $categoriasAct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                               <li><a href="<?php echo e(url('categoria/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('atractivosTuristicos')); ?>">Atractivos Turísticos</a>
                                        <ul class="dropdown-menu">
                                               <?php if($categoriasTu->count()): ?>
                                                    <?php $__currentLoopData = $categoriasTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaTuristico/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </ul>
                                 </li>   
                                            
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                   <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('hospedaje')); ?>">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasHospedaje->count()): ?>
                                                    <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaHospedaje/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('alimentacion')); ?>">Alimentacion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasAlimentacion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasAlimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaAlimentacion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>

                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('diversion')); ?>">Diversion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasDiversion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasDiversion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaDiversion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url ('guia')); ?>">Guía Turística</a></li>
                                <li><a href="<?php echo e(url ('luaf')); ?>">Proceso de Licencia Turística LUAF</a></li>
                                <li><a href="<?php echo e(url ('eventos')); ?>">Agenda de Eventos</a></li>
                                <li><a href="<?php echo e(url ('proyectos')); ?>">Proyectos</a></li>  
                                <li><a href="<?php echo e(url ('catastros')); ?>">Catastros Turísticos</a></li>           
                            </ul>
                        </li>  

                        

                       
                        
                        <li class="scroll"><a href="<?php echo e(url ('contactos')); ?>">CONTACTOS</a></li>

                     
                      
                  
                                                       
                       
                </div>

            



            </div>
        </nav>
    </header>


<div class="container">
       <div class="row header">
            <div class="col-md-12">

                    <p class="contact"> ¿Cómo llegar? </p>
                
            </div>
        </div>
         <div class= "col-xs-12 col-md-12" aling="center">
            <p style="font-color='black';"> <span class="fa fa-eye"></span> Visto: <?php echo e($variable->contador_visitas); ?> </p>

            
        </div>


        

     

    <div class="row" style="padding-top:35px;">

        <?php if(count($llegar) >0): ?>

         


        <div class="col-md-6 col-lg-6">

       

        
        <div class="alert alert-success alert-dismissable desaparecer">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p><strong>El mapa aparecerá en la sección de abajo </strong></p>
        </div>

        
            <!-- begin panel group -->
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

            <?php if(count($llegar) >0): ?>  

            <?php $__currentLoopData = $llegar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <!-- panel 1 -->
                <div class="panel panel-default">
                    <!--wrap panel heading in span to trigger image change as well as collapse -->
                    <span class="side-tab" data-target="#tab<?php echo e($item->id); ?>" data-toggle="tab" role="tab" aria-expanded="false">
                        <div class="panel-heading" role="tab" id="headingOne"data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($item->id); ?>" aria-expanded="true" aria-controls="<?php echo e($item->id); ?>">
                            <h4 class="panel-title"><?php echo e($item->titulo); ?></h4>
                        </div>
                    </span>
                    
                    <div id="<?php echo e($item->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <?php echo $item->contenido; ?>

                        </div>
                    </div>
                </div> 
                <!-- / panel 1 -->
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div> <!-- / panel-group -->

            
             
        </div> <!-- /col-md-6 -->
        
        <div class="col-md-6 col-lg-6">
            <!-- begin macbook pro mockup -->
            <div class="md-macbook-pro md-glare">
                <div class="md-lid">
                    <div class="md-screen">
                    <!-- content goes here -->                
                        <div class="tab-featured-image">
                            <div class="tab-content">

                            <?php if(count($llegar) >0): ?>  

                               <?php $__currentLoopData = $llegar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane" id="tab<?php echo e($item->id); ?>">
										<?php echo $item->script; ?>

                                        
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </div> <!-- /col-md-6 -->


       
        <?php endif; ?>
    </div>  <!-- /row -->
</div> <!-- /container -->



       


        
                
 
                    
       

 

  
<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==5): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoPinterest" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->

    <script src="<?php echo e(url('frontend/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    
    <script src="<?php echo e(url('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/jquery.isotope.min.js')); ?>"></script>
    <script src="<?php echo e(url('administration/dist/js/alertify.js')); ?>"></script>
     <script src="<?php echo e(url('administration/dist/js/sweetalert.min.js')); ?>"></script>

    
 
    <script src="<?php echo e(url('frontend/js/main.js')); ?>"></script>

   



  



   


</body>

</html>







