<?php $__env->startSection('title'); ?>
<title>Todas los Proyectos</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<div class='oculto'>

<img src="<?php echo e(url('frontend/images/proyectos.jpg')); ?>" alt="">

</div>

<p class="sliderTitle2"> Proyectos </p>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>

                    <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categoriasAct->count()): ?>
                                            <?php $__currentLoopData = $categoriasAct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                               <li><a href="<?php echo e(url('categoria/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                         <a href="<?php echo e(url ('atractivosTuristicos')); ?>">Atractivos Turísticos</a>
                                        <ul class="dropdown-menu">
                                               <?php if($categoriasTu->count()): ?>
                                                    <?php $__currentLoopData = $categoriasTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaTuristico/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </ul>
                                 </li>   
                                            
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                   <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('hospedaje')); ?>">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasHospedaje->count()): ?>
                                                    <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaHospedaje/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('alimentacion')); ?>">Alimentacion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasAlimentacion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasAlimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaAlimentacion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>

                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('diversion')); ?>">Diversion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasDiversion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasDiversion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaDiversion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url ('guia')); ?>">Guía Turística</a></li>
                                <li><a href="#">Proceso de Licencia Turística LOAF</a></li>
                                <li><a href="<?php echo e(url ('eventos')); ?>">Agenda de Eventos</a></li>
                                <li><a href="<?php echo e(url ('proyectos')); ?>">Proyectos</a></li>  
                                <li><a href="<?php echo e(url ('catastros')); ?>">Catastros Turísticos</a></li>           
                            </ul>
                          </li> 




<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="row header">
            <div class="col-lg-12 col-md-12 col-sm-12">

                   <h1 class="column-title2">  <a id="turismo"> Proyectos Turísticos </a> </h1>


                
            </div>
        </div>


                <div id="item-lists">

                            <?php if(count($actividades) > 0): ?>

                                      
                            

                                <?php echo $__env->make('ajax-frontend/proyectos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <?php else: ?>

                             <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                             <img src="<?php echo e(url('frontend/images/sad.png')); ?>">

                                    <p> No se encontraron resultados </p>

                             </div>

                           

                            <?php endif; ?>


                     </div>


                   








<?php $__env->stopSection(); ?>


<?php $__env->startSection('derecho'); ?>



                    <h3 class="column-title">Proyectos</h3>
                    <div class="panel panel-default" style="background: #f5f5f5;">
                    
                    <div class="panel-body" id="menu2">
                    
                    <ul class="demo1" style="overflow-y: hidden; margin-bottom: 0px;">
                      
                      
                        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <li style="" class="news-item">
                            <table cellpadding="4">
                            <tbody><tr>
                            <tr><img src="<?php echo e(url('fotos/'.$noticia->path)); ?>" style="width: 100%;height: 200px;"> </tr>
                            <td>
                                 <h5 class="negro"><a class="negro" href="proyectos/<?php echo e($noticia->id); ?>"><?php echo e($noticia->titulo); ?></a></h5>
                                 
                                <p class="negro2" > <?php echo e($noticia->descripcion); ?> </p>  
                                
                                </td>
                            </tr>
                            </tbody></table>
                            </li>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                           
                            
                            
                            
                            
                        </ul>
                    </div>

                            <div class="panel-footer">
                                
                               
                                <div class="clearfix">
                                    

                                </div>
                                <a class="btn_noticias" href="<?php echo e(url ('proyectos')); ?>">Ver Más Proyectos</a>
                      
                            </div>
                    </div>


                      
             



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==5): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoPinterest" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->



<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

     <script src="<?php echo e(url('frontend/js/jquery.bootstrap.newsbox.min.js')); ?>"></script>

<script type="text/javascript">

    $(function(){

            $('a[href*=#turismo]').click(function() {

            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'')
                && location.hostname == this.hostname) {

                    var $target = $(this.hash);

                    $target = $target.length && $target || $('[name=' + this.hash.slice(1) +']');

                    if ($target.length) {

                        var targetOffset = $target.offset().top;

                        $('html,body').animate({scrollTop: targetOffset}, 1000);

                        return false;

                    }

            }

        });

        });


    $(window).on('hashchange', function() {
            if (window.location.hash) {
                var page = window.location.hash.replace('#', '');
                if (page == Number.NaN || page <= 0) {
                    return false;
                }else{
                    getData(page);
                }
            }
        });

          $(function () {
                $(".demo1").bootstrapNews({
                    newsPerPage: 1,
                    autoplay: true,
                    pauseOnHover:true,
                    direction: 'up',
                    newsTickerInterval: 4000,
                    onToDo: function () {
                        //console.log(this);
                    }
                });
		
		
        });

    $(document).ready(function()
    {
            $(document).on('click', '.pagination a',function(event)
            {
                location.href = "#turismo";
                $('li').removeClass('active');
                $(this).parent('li').addClass('active');
                event.preventDefault();

                var myurl = $(this).attr('href');
                var page=$(this).attr('href').split('page=')[1];

                getData(page);
                
            });
        });

        function getData(page){
                $.ajax(
                {
                    url: '?page=' + page,
                    type: "get",
                    datatype: "html",
                })
                .done(function(data)
                {
                    $("#item-lists").empty().html(data);
                    location.hash = page;
                })
                .fail(function(jqXHR, ajaxOptions, thrownError)
                {
                    alert('No response from server');
                });
        }

        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>