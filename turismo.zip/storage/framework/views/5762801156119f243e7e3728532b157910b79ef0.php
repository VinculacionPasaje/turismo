<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">

<div class="form-group">
    <label>Comentario</label>
    <select class="form-control select2" name="comentario_id" id="comentario_id" style="width: 100%;" >
        <option value="" disabled selected>Seleccione el comentario</option>
        <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($comment->id); ?>" >  <?php echo e($comment->comentario); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>

<div class="form-group">
    <?php echo Form::label('Respuesta'); ?>                                                
    <?php echo Form::textarea('comentario',null,['class'=>'form-control', 'rows' => 5]); ?>

</div>



