<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">


   <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Titulo'); ?>

                            <?php echo Form::text('titulo',null,['placeholder'=>'Nombre','class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Fecha del Post'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker" name = "fecha_post" value="<?php echo e(old('fecha_post')); ?>">
                        </div>
                    </div>
                </div>

</div>

<div class="form-group">
    <?php echo Form::label('Descripción'); ?>

    <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control']); ?>

</div>

<div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Foto','Foto:'); ?>

                            <?php echo Form::file('path',['class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <label>Eliga la Categoria</label>
                            <select class="form-control select2" name="id_categorias" id="categorias" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione la categoria</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if(old('id_categorias') == $categoria->id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected> <?php echo e($categoria->categoria); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($categoria->id); ?>"> <?php echo e($categoria->categoria); ?></option>
                                    <?php endif; ?>       
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                </div>

</div>

<div class="row" ><!--Inicio de row -->

            <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <label>Eliga la Parroquia</label>
                            <select class="form-control select2" name="id_parroquias" id="parroquias" style="width: 100%;" >
                                <option value="" disabled selected>Seleccione la Parroquia</option>
                                <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parroquia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if(old('id_parroquias') == $parroquia->id): ?>
                                        <option value="<?php echo e($parroquia->id); ?>" selected> <?php echo e($parroquia->parroquia); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($parroquia->id); ?>"> <?php echo e($parroquia->parroquia); ?></option>
                                    <?php endif; ?>       
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                </div>
                 <div class="col-md-6 col-xs-12">
                          <div class="form-group">
                        
                                <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

                            </div>
                </div>
                

</div>






  <div class="form-group">
                <?php echo Form::label('Contenido'); ?>

                
                                                
                <?php echo Form::textarea('contenido',null,['class'=>'form-control', 'rows' => 50]); ?>

                                
</div>

