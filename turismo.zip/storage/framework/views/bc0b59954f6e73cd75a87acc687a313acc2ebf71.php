<!doctype html>
<html class="home no-js" lang="">

<head>
  <!-- meta -->
 <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
   
  <!-- /meta -->

   <title>Atractivos</title>

   <link rel="stylesheet" href="<?php echo e(url('frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/prettyPhoto.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/bootstrap-submenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/mensajes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('administration/dist/css/alertify.css')); ?>">


     <link rel="stylesheet" href="<?php echo e(url('frontend/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/owl.transitions.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/owl.theme.css')); ?>">


    <link rel="shortcut icon" href="<?php echo e(url('frontend/images/ico/ico.ico')); ?>">
  
  


  
</head>


<body id="home" class="homepage" style="background: rgb(255, 255, 255);">
  

   <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    
    <header id="header">
        
        <nav id="main-menu" class="navbar navbar-default menu" style="z-index: 100000;" role="banner">

            
            

            

            <div class="container">
                
                <div class="navbar-header">
                    

                    
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    

                    
                    <a class="navbar-brand" href="<?php echo e(url ('/')); ?>"><img src="<?php echo e(url('frontend/images/logo2.png')); ?>" alt="logo"></a>
                </div>

                


                
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="scroll active"><a href="<?php echo e(url ('/')); ?>">INICIO</a></li>
						
						
                          <li class="dropdown">
						
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">PASAJE<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url ('parroquias')); ?>">Parroquias</a></li>
                                <li><a href="<?php echo e(url ('llegar')); ?>">¿Cómo Llegar?</a></li>
                                <li><a href="<?php echo e(url ('mapas')); ?>">Mapas</a></li>  
                                
                                <li><a href="<?php echo e(url ('preguntas')); ?>">Preguntas Frecuentes</a></li>   
                                <li><a href="<?php echo e(url ('material')); ?>">Material Turístico</a></li>            
                            </ul>
                             </li> 

                        <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >OFERTA<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('actividades')); ?>">Actividades</a>
                                        <ul class="dropdown-menu">

                                        <?php if($categoriasAct->count()): ?>
                                            <?php $__currentLoopData = $categoriasAct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li><a href="<?php echo e(url('categoria/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                               


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                       <a href="<?php echo e(url ('atractivosTuristicos')); ?>">Atractivos Turísticos</a>
                                       
                                        <ul class="dropdown-menu">
                                                <?php if($categoriasTu->count()): ?>
                                                    <?php $__currentLoopData = $categoriasTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaTuristico/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </ul>
                                 </li>   
                                            
                            </ul>
                        </li>    


                            
                          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >SERVICIOS<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                   <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('hospedaje')); ?>">Hospedaje</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasHospedaje->count()): ?>
                                                    <?php $__currentLoopData = $categoriasHospedaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaHospedaje/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('alimentacion')); ?>">Alimentacion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasAlimentacion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasAlimentacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaAlimentacion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>

                                 <li class="dropdown-submenu">
                                        <a href="<?php echo e(url ('diversion')); ?>">Diversion</a>
                                        <ul class="dropdown-menu">
                                            <?php if($categoriasDiversion->count()): ?>
                                                    <?php $__currentLoopData = $categoriasDiversion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a href="<?php echo e(url('categoriaDiversion/'.$cat->id)); ?>"><?php echo e($cat->categoria); ?></a></li>
                                                    


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                        </ul>
                                 </li>
                                         
                            </ul>
                        </li>    
 

                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >GESTIÓN<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                  <li><a href="<?php echo e(url ('guia')); ?>">Guía Turística</a></li>
                                <li><a href="<?php echo e(url ('luaf')); ?>">Proceso de Licencia Turística LUAF</a></li>
                                <li><a href="<?php echo e(url ('eventos')); ?>">Agenda de Eventos</a></li>
                                <li><a href="<?php echo e(url ('proyectos')); ?>">Proyectos</a></li>  
                                <li><a href="<?php echo e(url ('catastros')); ?>">Catastros Turísticos</a></li>             
                            </ul>
                        </li>  

                        

                       
                        
                        <li class="scroll"><a href="<?php echo e(url ('contactos')); ?>">CONTACTOS</a></li>
                      
                     
                      
                  
                                                       
                       
                </div>

            



            </div>
        </nav>
    </header>


    <div id="carousel">
            <div id="owl-demo" class="owl-carousel owl-theme"> 

                         <?php $__currentLoopData = $actividades_filtradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                        <div class="item">
                                                <img src="<?php echo e(url('fotos/'.$act->path)); ?>" alt="">
                                                <div class="line"> 
                                                    <div class="text hide-s">
                                                        <div class="line"> 
                                                        <div class="prev-arrow">
                                                            <i class="fa fa-chevron-left"></i>
                                                        </div>
                                                        <div class="next-arrow">
                                                            <i class="fa fa-chevron-right"></i>
                                                        </div>
                                                        </div> 
                                                        <h2><?php echo e($act->titulo); ?></h2>
                                                        <p><?php echo e($act->descripcion); ?>


                                                        </p>
                                                         <?php echo link_to('atractivosTuristicos/'.$act->id.'', $title = 'Más Información', $attributes = ['class'=>'slider_btn_banner'], $secure = null); ?>

                                                        
                                                    </div>
                                                </div>
                                            </div>   


                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            

            

            </div>
    </div>




<div class="container" style="padding-bottom: 70px; padding-top:25px;">



      <div class="row header">
            <div class="col-lg-12 col-md-12 col-sm-12">

                    <h1 class="column-title2"> <?php echo e($todo->titulo_atractivos); ?> </h1>


                
            </div>
        </div>

         <div class= "col-xs-12 col-md-12">
            <p style="font-color='black';text-align: justify; font-size: 16px" > 

             <?php echo $todo->contenido_atractivos; ?>


                 
             </p>

            
        </div>



        



            <div class="col-lg-12 col-md-12 col-sm-12" id="post-data">

                       <?php echo $__env->make('ajax-frontend/turistico', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        

                        
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                        <button type= "button" class="slider_btn4 loadMore"> Ver Mas </button>

                        </div>
                
                <div class="ajax-load text-center" style="display:none">
                            <p><img src="<?php echo e(url('frontend/images/loader.gif')); ?>">Cargando más post</p>
                        </div>


        

    
</div> <!-- /container -->



       


        
                
 
                    
       

 

  
<div  class="col-xs-12 col-md-12 fondo1">   </div>
    <footer id="footer">
    
        <div class="container">

               <div class="col-xs-12 col-md-12 col-sm-12" style="padding-bottom: 10px; padding-top:15px;" align="center">
                   <img src="<?php echo e(url('frontend/images/logo3.png')); ?>" alt="logo">
                

                   
                </div>

            
            
                <div class="col-xs-12 col-md-12 col-sm-12">

                    <?php if(count($footer) >0): ?>
                        <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="blanco" >Gobierno Autónomo Descentralizado Municipal del Cantón Pasaje <br>
                                <?php echo e($item->direccion); ?> | Telf. <?php echo e($item->telefono); ?> | Fax. <?php echo e($item->fax); ?> | Web: <?php echo e($item->web); ?> | Email: <?php echo e($item->email); ?>

                                <br>® Todos los Derechos Reservados | Pasaje, El Oro, Ecuador <?php echo e($item->anio); ?>

                                
                                </p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="redessocial2" align="center" >
                                <ul class="social-network social-circle">

                                <?php if(count($redes) >0): ?>


                                 <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($red->id==1): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==2): ?>

                                            <li><a href="<?php echo e($red->url); ?>" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                <?php endif; ?>


                                                <?php if($red->id==3): ?>

                                                <li><a href="<?php echo e($red->url); ?>" class="icoRss" title="Instagram"><i class="fa fa-instagram"></i></a></li>

                                                <?php endif; ?>

                                                <?php if($red->id==4): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($red->id==5): ?>
                                                    <li><a href="<?php echo e($red->url); ?>" class="icoPinterest" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                <?php endif; ?>

                                                

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                <?php endif; ?>
                                   
                                        
                                </ul>				
                                                                                    
                            </div>
                

                   
                </div>

                
           
        </div>
    </footer><!--/#footer-->

    <script src="<?php echo e(url('frontend/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    
    <script src="<?php echo e(url('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/jquery.isotope.min.js')); ?>"></script>
    <script src="<?php echo e(url('administration/dist/js/alertify.js')); ?>"></script>
     <script src="<?php echo e(url('administration/dist/js/sweetalert.min.js')); ?>"></script>

    
 
    <script src="<?php echo e(url('frontend/js/main.js')); ?>"></script>

     <script src="<?php echo e(url('frontend/js/owl.carousel.min.js')); ?>"></script>


     <script type="text/javascript">
            var page = 1;


            $(document).ready(function(){

                            $('.loadMore').click(function(){

                                page++;
                                loadMoreData(page);

                        


                                });

                        });

            function loadMoreData(page){
            $.ajax(
                    {
                        url: '?page=' + page,
                        type: "get",
                        beforeSend: function()
                        {
                            $('.ajax-load').show();
                        }
                    })
                    .done(function(data)
                    {
                        if(data.html.length == "0"){
                            $("button").text("Ya no hay más posts").attr("disabled", "disabled");
                            $('.ajax-load').html("Ya no hay mas resultados");
                        return;
                        }
                        $('.ajax-load').hide();
                        $("#post-data").append(data.html);
                    })
                    .fail(function(jqXHR, ajaxOptions, thrownError)
                    {
                        alert('error al cargar los datos...');
                    });
            }
        </script>



    <script type="text/javascript">
         jQuery(document).ready(function($) {
            var theme_slider = $("#owl-demo");
            $("#owl-demo").owlCarousel({
                navigation: false,
                slideSpeed: 300,
                paginationSpeed: 400,
                autoPlay: 6000,
                addClassActive: true,
             // transitionStyle: "fade",
                singleItem: true
            });
            $("#owl-demo2").owlCarousel({
                slideSpeed: 300,
                autoPlay: true,
                navigation: true,
                navigationText: ["&#xf007","&#xf006"],
                pagination: false,
                singleItem: true
            });

            
        
            // Custom Navigation Events
            $(".next-arrow").click(function() {
                theme_slider.trigger('owl.next');
            })
            $(".prev-arrow").click(function() {
                theme_slider.trigger('owl.prev');
            })     
        }); 

      

     


        $(document).ready(function(){
            var altura = $('.menu').offset().top;
            
            $(window).on('scroll', function(){
                if ( $(window).scrollTop() > altura ){
                    $('.menu').addClass('menu-fixed');
                } else {
                    $('.menu').removeClass('menu-fixed');
                }
            });
        
        });

      

        


        (function () {
                var previousScroll = 0;

                $(window).scroll(function(){
                var currentScroll = $(this).scrollTop();
                if (currentScroll > previousScroll){

                        //$('.menu').hide('slow');

                    $('.menu').addClass('desaparece');
                    $('.menu').removeClass('aparece');

                    //para abajo
                    
                } else {

                    //$('.menu').show('slow');
                    
                        

                    $('.menu').addClass('aparece');
                    $('.menu').removeClass('desaparece');
                    
                    

                    //para arriba
                }
                previousScroll = currentScroll;
                });
            }()); //run this anonymous function immediately


      

       

      </script>

   



  



   


</body>

</html>