
                  
                  
                   <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                        
                                                
                                 <div class="blog-post blog-large" style= "padding-bottom: 25px;" >
                                        <article>
                                            <header class="entry-header">
                                                <div class="entry-thumbnail">
                                                   <a href="noticias/<?php echo e($act->id); ?>" > <img class="img-responsive" src="<?php echo e(url('fotos/'.$act->path)); ?>" alt=""> </a>
                                                    
                                                </div>
                                                <div class="entry-date"><?php echo e($act->fecha_post); ?></div>
                                                <h3 class="entry-title" align= "center"><a href="noticias/<?php echo e($act->id); ?>"><?php echo e($act->titulo); ?></a></h3>
                                            </header>

                                            <div class="entry-content">
                                                <P class="negro2"> <?php echo e($act->descripcion); ?>  </P>
                                            
                                            </div>

                                        
                                        </article>
                                    </div>
                                        
                                                    
                                            
                                                    
                                                
                                
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                             <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                          <?php echo $actividades->render(); ?>


                        </div>