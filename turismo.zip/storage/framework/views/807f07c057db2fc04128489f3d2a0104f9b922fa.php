             <articles class="row">
                    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                                                        

                    <article class="col-sm-6 col-xs-6 col-md-3 col-lg-3">
                            <a href="<?php echo e(url('fotos/'.$imagen->path)); ?>" data-lightbox="example-set" data-title="<?php echo e($imagen->titulo); ?>">
                            <img style="width: 100%;height: 250px;" src="<?php echo e(url('fotos/'.$imagen->path)); ?>" alt="<?php echo e($imagen->titulo); ?>" class="img-thumbnail"></a>
                          
                        </article>
                            


                                

                                                
                                                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
   
			</articles>   
		
  
