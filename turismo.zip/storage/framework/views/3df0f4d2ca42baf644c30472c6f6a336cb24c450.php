
                  
                  
                   <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                        
                                                
                                <div class="col-lg-4 col-md-4 col-sm-4" style="padding-bottom:25px;">

                                        <div class="blog-post blog-large">
                                            <article>
                                                <header class="entry-header">
                                                    <div class="entry-thumbnail">
                                                       <a href="eventos/<?php echo e($act->id); ?>" > <img class="img-responsive5" src="<?php echo e(url('fotos/'.$act->path)); ?>" alt="<?php echo e($act->titulo); ?>"> </a>
                                                        
                                                    </div>
                                                    
                                                    <h3 class="entry-title" align="center"><a href="eventos/<?php echo e($act->id); ?>"><?php echo e($act->titulo); ?></a></h3>
                                                    <div class="entry-date"><?php echo e($act->fecha_post); ?></div>
                                                </header>

                                                <div class="entry-content">
                                                    <P class="home-paragraph " style="text-align: justify; font-size:14px;"><?php echo e($act->descripcion); ?></P>

                                                    <P class="negro2" style="text-align: justify; font-size:12px;"> <div style= "float: left; margin-right: 7px;"> <i class="fa fa-calendar fa-1x"></i> </div> <span> Del <?php echo e($act->fecha_desde); ?> al <?php echo e($act->fecha_hasta); ?> </span></P>
                                                    <P class="negro2" style="text-align: justify; font-size:12px;"> <div style= "float: left; margin-right: 10px;"> <i class="fa fa-clock-o fa-1x" aria-hidden="true"></i>  </div> <span> <?php echo e($act->hora_inicio); ?> </span> </P>
                                                    <P class="negro2" style="text-align: justify; font-size:12px;"> <div style= "float: left; margin-right: 14px; margin-left: 3px;"><i class="fa fa-map-marker fa-1x"></i> </div> <span> <?php echo e($act->direccion); ?></span> </P>
                                                   

                                                
                                                </div>

                                            </article>
                                        </div>
                                </div>
                                        
                                                    
                                            
                                                    
                                                
                                
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                             <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                          <?php echo $actividades->render(); ?>


                        </div>

                        