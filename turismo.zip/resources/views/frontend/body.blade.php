<b>De: </b> {{ $nombre }}
<br>
<br>
<b> Asunto: </b> {{ $subject }}
<br>
<br>

{{ $body }}

<br>
<br>
<b> Señor administrador responder a este correo: </b> {{ $email }}