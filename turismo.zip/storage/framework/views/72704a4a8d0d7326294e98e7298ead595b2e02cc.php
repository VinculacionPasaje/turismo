<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">



<div class="form-group">
    <?php echo Form::label('Titulo'); ?>

    <?php echo Form::text('titulo',null,['placeholder'=>'Nombre','class'=>'form-control']); ?>

</div>
               


<div class="form-group">
    <?php echo Form::label('Script'); ?>

    <?php echo Form::text('script',null,['placeholder'=>'ingrese el script de google map','class'=>'form-control']); ?>

</div>



  <div class="form-group">
                <?php echo Form::label('Contenido'); ?>

                
                                                
                <?php echo Form::textarea('contenido',null,['class'=>'form-control', 'rows' => 50]); ?>

                                
</div>


<?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>