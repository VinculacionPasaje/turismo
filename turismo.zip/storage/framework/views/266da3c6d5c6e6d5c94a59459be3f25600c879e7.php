<?php $__env->startSection('title'); ?>
<title>Login</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

      

        <div class="page-container">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span>  <h1>Login</h1>
                </div>
                <div class="panel-body">
           
                                    <form action="<?php echo e(route('login')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        
                                        

                                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Correo Electronico">
                                        
                                                        <?php if($errors->has('email')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    
                                        </div>

                                        

                                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">

                                                    <input id="password" type="password" class="form-control" name="password" required placeholder="Password">

                                                        <?php if($errors->has('password')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    

                                                
                                                </div>

                                                <div class="form-group">
                                                
                                                        <button type="submit">
                                                            Ingresar
                                                        </button>

                                                       
                                                
                                                </div>

                                    
                                        <div class="error"><span>+</span></div>
                                    </form>
                                <div class="panel-footer">

                                     <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                            Olvidaste la contraseña?
                                                        </a>
    
                                       
                                </div>
                         </div>
                 </div>
            
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>