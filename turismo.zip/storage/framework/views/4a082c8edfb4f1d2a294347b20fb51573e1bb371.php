<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>
            Dashboard
            <small>Panel de Control</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Inicio</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

   

        <div class="row">
            <div style="background: url('../frontend/images/fondo.jpg') no-repeat;width:300px;height:300px" class="col-md-12">
               

            </div>
            <!-- /.col (RIGHT) -->
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>