<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>
            Inicio
            <small>Listar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Inicio</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensaje-registro')): ?>
        <?php echo $__env->make('mensajes.msj_correcto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Usuarios Registrados</h3>

                
                </div>
                <!-- /.box-header -->
                 <?php if(count($usuarios) >0): ?>

                  

                 <div class="ajax-tabla">
                        <div class="box-body table-responsive no-padding" >
                            <table id="example2" class="table table-hover" >
                            <thead>
                                <tr>
                                    <th>Foto</th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>Email</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($usuario->estado !=0): ?>
                                    <tr data-id="<?php echo e($usuario->id); ?>">
                                        <?php if($usuario->path!=null): ?>
                                            <td>
                                                <img src="<?php echo e(url('fotos/'.$usuario->path)); ?>" alt="" style="width:50px;"/>
                                            </td>
                                        <?php else: ?>
                                            <td>
                                                <img src="<?php echo e(url('fotos/no-avatar.png')); ?>" alt="" style="width:50px;"/>
                                            </td>
                                        <?php endif; ?>
                                       
                                        <td><?php echo e($usuario->name); ?></td>
                                        <td><?php echo e($usuario->apellido); ?></td>
                                        <td><?php echo e($usuario->email); ?></td>
                                        
                                        <td>
                                            <?php if(Auth::user()->id_roles == 2): ?>
                                            <?php echo link_to_route('usuarios.edit', $title = 'Editar', $parameters = $usuario->id, $attributes = ['class'=>'btn  btn-primary btn-sm', 'disabled'], array('disabled')); ?>

                                            <button type="button" class="btn btn-danger btn-sm btn-delete" disabled ><i class="zmdi zmdi-floppy"></i> &nbsp;&nbsp;Eliminar</button>
                                            <?php else: ?>
                                            <?php echo link_to_route('usuarios.edit', $title = 'Editar', $parameters = $usuario->id, $attributes = ['class'=>'btn  btn-primary btn-sm']); ?>

                                            <button type="button" class="btn btn-danger btn-sm btn-delete" ><i class="zmdi zmdi-floppy"></i> &nbsp;&nbsp;Eliminar</button>


                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <?php echo e($usuarios->links()); ?>

                        </div>
                    </div>

                <?php else: ?>
                    <br/><div class='rechazado'><label style='color:#FA206A'>...No se ha encontrado ningun Usuario...</label>  </div>
                <?php endif; ?>
              
            </div>
            <!-- /.box -->
        </div>
    </div>

    <?php echo Form::open(['route' => ['usuarios.destroy', ':USER_ID'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('administration/dist/js/usuarios/delete-usuarios.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $(".aprobado").fadeOut(300);
            },3000);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>