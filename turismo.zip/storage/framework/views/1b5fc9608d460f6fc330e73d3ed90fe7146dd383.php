<b>De: </b> <?php echo e($nombre); ?>

<br>
<br>
<b> Asunto: </b> <?php echo e($subject); ?>

<br>
<br>

<?php echo e($body); ?>


<br>
<br>
<b> Señor administrador responder a este correo: </b> <?php echo e($email); ?>