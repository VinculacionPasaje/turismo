<input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">

<div class="form-group">
    <?php echo Form::label('Comentario'); ?>                                                
    <?php echo Form::textarea('comentario',null,['class'=>'form-control', 'rows' => 5]); ?>

</div>

<div class="form-group">
    <label>Usuario</label>
    <select class="form-control select2" name="usuario_id" id="usuarios" style="width: 100%;" >
        <option value="" disabled selected>Seleccione el usuario</option>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($usuario->id); ?>" >  <?php echo e($usuario->name.' '.$usuario->apellido); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>Noticia</label>
    <select class="form-control select2" name="noticias_id" id="noticias" style="width: 100%;" >
        <option value="" disabled selected>Seleccione la noticia</option>
        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($noticia->id); ?>" >  <?php echo e($noticia->titulo); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>
