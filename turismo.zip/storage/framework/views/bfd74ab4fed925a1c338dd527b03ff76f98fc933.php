<?php $__env->startSection('title'); ?>
    <section class="content-header">
        <h1>Galeria<small>Editar</small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Inicio</a></li>
            <li class="active">Galeria</li>
            <li class="active">Editar</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <?php if(session('mensaje-registro')): ?>
        <?php echo $__env->make('mensajes.msj_correcto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <?php if(!$errors->isEmpty()): ?>
        <div class="alert alert-danger">
            <p><strong>Error!! </strong>Corrija los siguientes errores</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">Editar Contenido</h3>
        </div><!-- /.box-header -->
        <div class="box-body">
            <?php echo e(Form::model($galeria, ['route' => ['galeriasNoticias.update',$galeria->id],'method'=>'PUT','files' => true ])); ?>

            <div id="msj-success" class="alert alert-success alert-dismissible aprobado" role="alert" style="display:none">
                <strong> Contenido Editado Correctamente.</strong>
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
            <input type="hidden" name="ruta" id ="ruta" value="<?php echo e(url('')); ?>">
            
            <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Titulo'); ?>

                            <?php echo Form::text('titulo',null,['placeholder'=>'Nombre','class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">
                         <div class="form-group">
                            <?php echo Form::label('Fecha Noticia'); ?>

                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right" id="datepicker" name = "fecha_post" value="<?php echo e($galeria->fecha_post); ?>">
                        </div>
                    </div>
                </div>

            </div>

            

            <div class="form-group">
                <?php echo Form::label('Descripción'); ?>

                <?php echo Form::text('descripcion',null,['placeholder'=>'Descripcion','class'=>'form-control']); ?>

            </div>

            <div class="row" ><!--Inicio de row -->
                 <div class="col-md-6 col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label('Foto','Foto:'); ?>

                            <?php echo Form::file('path',['class'=>'form-control']); ?>

                        </div>
                </div>
                <div class="col-md-6 col-xs-12">


                       <label>Categoria</label>
                    <select class="form-control" name="noticias_id" id="categorias" style="width: 100%;" >
                        <option value="" disabled selected>Seleccione la categoria</option>

                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($categoria->id == $galeria->noticias->id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected>  <?php echo e($categoria->titulo); ?> </option>
                                    <?php else: ?>
                                        <option value="<?php echo e($categoria->id); ?>">  <?php echo e($categoria->titulo); ?> </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>



                </div>

            </div>


            <div class="row" ><!--Inicio de row -->
         
                <div align="center" class="col-md-6 col-xs-12">
                        
                     <?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>

                </div>

            </div>

         

           

            
            
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('administration/dist/js/noticias/java-noticias.js')); ?>"></script>
     <script src="<?php echo e(url('administration/dist/js/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $(".aprobado").fadeOut(300);
            },3000);
        });
    </script>

     <script>
        $(function() {
                $.fn.datepicker.dates['en'] = {
                    days: [ "Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado" ],
                    daysShort: ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
                    daysMin: ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"],
                    months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
                        "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
                    monthsShort: ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
                        "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
                    today: "Hoy",
                    clear: "Clear",
                    titleFormat: "MM yyyy", /* Leverages same syntax as 'format' */
                    weekStart: 0
                };
                $("#datepicker").datepicker({
                    format: 'yyyy/mm/dd',
                    language:'en'
                })
                $("#datepicker2").datepicker({
                    format: 'yyyy/mm/dd',
                    language:'en'
                })
            });

    </script>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>